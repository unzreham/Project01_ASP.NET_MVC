import React, { useState, useEffect } from 'react';
import axios from 'axios';

// const PlaceDetails = (props) => {

//     let [Places, setPlaces] = useState();
//     useEffect(() => {
//         getAll();
     
//       }, [ ]);

//     function getAll() {
//           axios
//           .get("https://localhost:44351/api/Places/1")
//           .then((res) => {
//            console.log(res.data);
//             setPlaces(res.data) 
//           })
//           .catch((err) => console.error(err));
    
    
    
//       }
//     return (
    

//         </div>
//     )
// };

// export default PlaceDetails;









{/* <div className = "container-sm">
<p>  hi {props.pk}  </p>

        <div class="card col-md-12 p-3">
        <div class="row ">
            <div class="col-md-8">
                <div class="card-block">
                    <h6 class="card-title text-right">{Places.placeName}</h6>
                    <p class="card-text text-justify">{Places.description}.</p>
                    <a href="#" class="btn btn-primary">read more...</a>
                </div>
            </div>
            <div class="col-md-4">
                <img class="" src={Places.photo} style={{width: "300px", height:"300px" }} />
            </div>
        </div>
    </div> */}




const PlaceDetails = (props) => {
   

    const [PlaceData, setPlaceData] = useState([])
  


    useEffect(() => {
      getPlaceInfo();
  
    },[ ]);
    
    const getPlaceInfo=()=>{
      axios
      .get(`https://localhost:44351/api/Places/${props.pk}/?format=json`)
      .then((res) => {
          setPlaceData(res.data)
          console.log(res.data)
        })
      .catch((err) => console.error(err));
    }
    
    
    return (
        
        <div className="container-md position-absolute top-50 start-50 translate-middle">
        {/* <p>hi {props.pk}</p> */}
        <div class="card col-md-12 p-3">
        <div class="row ">
            <div class="col-md-8">
                <div class="card-block">
                    <h6 class="card-title text-right">{PlaceData.placeName}</h6>
                    <p class="card-text text-justify">{PlaceData.description}.</p>
                    <a href="#" class="btn btn-outline-warning ">read more...</a>
                </div>
            </div>
            <div class="col-md-4">
                <img class="" src={PlaceData.photo} style={{width: "300px", height:"300px" }} />
            </div>
        </div>
    </div>
        </div>
    )
};

export default PlaceDetails;
